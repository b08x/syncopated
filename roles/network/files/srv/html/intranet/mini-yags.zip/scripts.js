/* eslint-disable no-undef */
/* eslint-disable no-unused-vars */

/**
 * Search function
 */

const searchInput = document.querySelector("#searchbar > input")
const searchButton = document.querySelector("#searchbar > button")

const lookup = {"/":"/","deepl":"https://deepl.com/","reddit":"https://reddit.com/","maps":"https://maps.google.com/"}
const engine = "https://cse.google.com/cse?cx=7586a3b5428dd436e#gsc.tab=0&gsc.q={query}"
const engineUrls = {
  deepl: "https://www.deepl.com/translator#-/-/{query}",
  duckduckgo: "https://duckduckgo.com/?q={query}",
  ecosia: "https://www.ecosia.org/search?q={query}",
  google: "https://www.google.com/search?q={query}",
  startpage: "https://www.startpage.com/search?q={query}",
  youtube: "https://www.youtube.com/results?q={query}",
}

const isWebUrl = value => {
  try {
    const url = new URL(value)
    return url.protocol === "http:" || url.protocol === "https:"
  } catch {
    return false
  }
}

const getTargetUrl = value => {
  if (isWebUrl(value)) return value
  if (lookup[value]) return lookup[value]
  const url = engineUrls[engine] ?? engine
  return url.replace("{query}", value)
}

const search = () => {
  const value = searchInput.value
  const targetUrl = getTargetUrl(value)
  window.open(targetUrl, "_self")
}

searchInput.onkeyup = event => event.key === "Enter" && search()
searchButton.onclick = search

/**
 * inject bookmarks into html
 */

const bookmarks = [{"id":"oMwc3ifRGeEtReNT","label":"design tools","bookmarks":[{"id":"t4BaaOUeGHqaBRTk","label":"asciiflow","url":"https://asciiflow.com/legacy/"}]},{"id":"6dsuwcrzT0xIHYzN","label":"sources","bookmarks":[{"id":"kbnJ2QRqOJFyD8f9","label":"icons","url":"https://feathericons.com/"}]},{"id":"VJ3WWVJaKpWgrBhd","label":"llm","bookmarks":[{"id":"nCshlbgTuOIWBWQZ","label":"monadic","url":"http://tinybot.syncopated.net:8082"},{"id":"urG2Cso8VGScAq1z","label":"flowise","url":"http://ninjabot.syncopated.net:3002"}]},{"id":"FM5dWnrAuj7dqMWm","label":"local","bookmarks":[{"id":"w1RfnpxqMjhFLDaC","label":"linkding","url":"http://bender.syncopated.net:9090"}]},{"id":"62VW0VQu1mqRoSkp","label":"databse","bookmarks":[{"id":"uDFXUhA9tsVd9XVj","label":"redis cache","url":"http://ninjabot.syncopated.net:8001"}]},{"id":"5n7ehMUekcwfvRYu","label":"gpt","bookmarks":[{"id":"GycdmcCMyh1lXXHT","label":"bard","url":"https://bard.google.com/chat"},{"id":"BfPOfYTQDNYrEmYC","label":"claude","url":"https://claude.ai/"},{"id":"x5eF2uDeiZ8rCqON","label":"chatgpt","url":"https://chat.openai.com/"}]}]

const createGroupContainer = () => {
  const container = document.createElement("div")
  container.className = "bookmark-group"
  return container
}

const createGroupTitle = title => {
  const h2 = document.createElement("h2")
  h2.innerHTML = title
  return h2
}

const createBookmark = ({ label, url }) => {
  const li = document.createElement("li")
  const a = document.createElement("a")
  a.href = url
  a.innerHTML = label
  li.append(a)
  return li
}

const createBookmarkList = bookmarks => {
  const ul = document.createElement("ul")
  bookmarks.map(createBookmark).forEach(li => ul.append(li))
  return ul
}

const createGroup = ({ label, bookmarks }) => {
  const container = createGroupContainer()
  const title = createGroupTitle(label)
  const bookmarkList = createBookmarkList(bookmarks)
  container.append(title)
  container.append(bookmarkList)
  return container
}

const injectBookmarks = () => {
  const bookmarksContainer = document.getElementById("bookmarks")
  bookmarksContainer.append()
  bookmarks.map(createGroup).forEach(group => bookmarksContainer.append(group))
}

injectBookmarks()
