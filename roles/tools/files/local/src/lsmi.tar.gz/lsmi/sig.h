void set_traps __P(( void ));
void die __P(( int sig ));
